-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2019 at 02:00 AM
-- Server version: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `app_id` int(15) NOT NULL,
  `order_id` int(15) NOT NULL,
  `GS_id` int(15) NOT NULL,
  `OS_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `username` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(30) NOT NULL,
  `category_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(12345, 'plumber');

-- --------------------------------------------------------

--
-- Table structure for table `get_services`
--

CREATE TABLE `get_services` (
  `GS_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `title` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `city` varchar(15) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `offer_service`
--

CREATE TABLE `offer_service` (
  `OS_id` int(15) NOT NULL,
  `title` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `city` varchar(15) NOT NULL,
  `available_from` datetime NOT NULL,
  `available_to` datetime NOT NULL,
  `category_id` int(15) NOT NULL,
  `sub_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(15) NOT NULL,
  `GS_id` int(15) NOT NULL,
  `OS_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `username` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_id` int(30) NOT NULL,
  `sub_name` varchar(30) NOT NULL,
  `category_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_id`, `sub_name`, `category_id`) VALUES
(123, 'carpenter', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(15) NOT NULL,
  `F_name` varchar(30) NOT NULL,
  `L_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(15) NOT NULL,
  `username` varchar(15) NOT NULL,
  `birthday` int(11) NOT NULL,
  `accesstoken` int(11) NOT NULL,
  `dateandtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `F_name`, `L_name`, `email`, `password`, `username`, `birthday`, `accesstoken`, `dateandtime`) VALUES
(1, 'daniyal', 'sajid', 'daniyalbinsajid@gmail.com', 'abc12345', 'daniyalsajid', 24091993, 0, '2019-12-11 00:00:00'),
(3, 'hassan', 'ahmed', 'hassan321', 'sdwww', 'hassanMehmood', 24091993, 0, '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`app_id`),
  ADD KEY `GS_id` (`GS_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `OS_id` (`OS_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `get_services`
--
ALTER TABLE `get_services`
  ADD PRIMARY KEY (`GS_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `offer_service`
--
ALTER TABLE `offer_service`
  ADD PRIMARY KEY (`OS_id`),
  ADD KEY `sub_id` (`sub_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`,`username`),
  ADD KEY `OS_id` (`OS_id`),
  ADD KEY `GS_id` (`GS_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_id`,`sub_name`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `app_id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12346;
--
-- AUTO_INCREMENT for table `get_services`
--
ALTER TABLE `get_services`
  MODIFY `GS_id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `offer_service`
--
ALTER TABLE `offer_service`
  MODIFY `OS_id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`GS_id`) REFERENCES `get_services` (`GS_id`),
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`),
  ADD CONSTRAINT `application_ibfk_3` FOREIGN KEY (`OS_id`) REFERENCES `offer_service` (`OS_id`),
  ADD CONSTRAINT `application_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `get_services`
--
ALTER TABLE `get_services`
  ADD CONSTRAINT `get_services_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `offer_service`
--
ALTER TABLE `offer_service`
  ADD CONSTRAINT `offer_service_ibfk_1` FOREIGN KEY (`sub_id`) REFERENCES `sub_category` (`sub_id`),
  ADD CONSTRAINT `offer_service_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`user_id`,`username`) REFERENCES `user` (`user_id`, `username`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`OS_id`) REFERENCES `offer_service` (`OS_id`),
  ADD CONSTRAINT `order_ibfk_3` FOREIGN KEY (`GS_id`) REFERENCES `get_services` (`GS_id`);

--
-- Constraints for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD CONSTRAINT `sub_category_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
